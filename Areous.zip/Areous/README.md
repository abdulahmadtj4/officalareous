Brandi HTML5 Bootstraped Business Template
========

<img src ="https://cloud.githubusercontent.com/assets/10640964/5989549/0f93dfc8-a9b6-11e4-8f1e-75189f6a5759.jpg" />

<a href="http://themefisher.com/download/brandi-corporate-template/> Live Preview </a>

=========

Brandi is a corporate template that is perfect for individuals or businesses. This theme comes with crisp animation and is responsive meaning it looks great on all devices.These demo is just a example … you can make your own color schemes to further customize your template.

Key Feature

100% Responsive Design
Bootstrap 3.2 Compatible
Valid HTML5/CSS3 Markup
Google Fonts Support
Clean Code, All files are well commented and organized
Documentation File Included
PSD credit: https://dribbble.com/themecurve

A template By <a href="http://www.themefisher.com>Themefisher</a>
